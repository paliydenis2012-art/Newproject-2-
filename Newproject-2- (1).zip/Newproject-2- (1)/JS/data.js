let games = []
let cart = []

fetch("games.json")
.then(res => res.json())
.then(data => {
games = data
showGames(games)
})

function showGames(list){

const container = document.getElementById("games")
container.innerHTML = ""

list.forEach(game => {

container.innerHTML += `
<div class="game">
<img src="${game.image}">
<h4>${game.name}</h4>
<p>$${game.price}</p>
<button onclick="addToCart(${game.id})">Купити</button>
</div>
`

})
}

function addToCart(id){

cart.push(id)

document.getElementById("cart-count").innerText = cart.length

}

document.getElementById("search").addEventListener("input", function(){

const value = this.value.toLowerCase()

const filtered = games.filter(g =>
g.name.toLowerCase().includes(value)
)

showGames(filtered)

})