let games = []
let cart = []

fetch("games.json")
.then(res => res.json())
.then(data => {

games = data
showGames(games)

})

function showGames(list){

const container = document.getElementById("games")
container.innerHTML = ""

list.forEach(game => {

container.innerHTML += `
<div class="game">
<img src="${game.image}">
<h3>${game.name}</h3>
<p>$${game.price}</p>
<button onclick="addToCart(${game.id})">Купити</button>
</div>
`

})

}

function addToCart(id){

cart.push(id)

document.getElementById("cart-count").innerText = cart.length

}

document.getElementById("search").addEventListener("input", function(){

let value = this.value.toLowerCase()

let filtered = games.filter(game =>
game.name.toLowerCase().includes(value)
)

showGames(filtered)

})

document.getElementById("sort").addEventListener("change", function(){

let sorted = [...games]

if(this.value === "low"){
sorted.sort((a,b)=>a.price-b.price)
}

if(this.value === "high"){
sorted.sort((a,b)=>b.price-a.price)
}

showGames(sorted)

})

function showCart(){

document.getElementById("games").style.display="none"
document.getElementById("cart").style.display="grid"

let container = document.getElementById("cart")
container.innerHTML=""

let total = 0

cart.forEach((id,index)=>{

let game = games.find(g=>g.id==id)

container.innerHTML += `
<div class="game">
<img src="${game.image}">
<h3>${game.name}</h3>
<p>$${game.price}</p>
<button onclick="removeFromCart(${index})">❌</button>
</div>
`

total += game.price

})

container.innerHTML += `<h2>Сума: $${total}</h2>`

}

function removeFromCart(index){

cart.splice(index,1)

document.getElementById("cart-count").innerText = cart.length

showCart()

}

function showStore(){

document.getElementById("games").style.display="grid"
document.getElementById("cart").style.display="none"

}