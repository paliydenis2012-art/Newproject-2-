let games = []
let cart = []

fetch("products.json")
.then(res => res.json())
.then(data => {
products = data
showProducts(products)
})

function showProducts(list){

const container = document.getElementById("games")
container.innerHTML = ""

list.forEach(product => {
container.innerHTML += `
<div class="game">
<img src="${product.image}">
<h4>${product.name}</h4>
<p>$${product.price}</p>
<button onclick="addToCart(${product.id})">Купити</button>
</div>
`
})

}

document.getElementById("search").addEventListener("input", function(){

const value = this.value.toLowerCase()

const filtered = games.filter(g =>
g.name.toLowerCase().includes(value)
)

showGames(filtered)

})